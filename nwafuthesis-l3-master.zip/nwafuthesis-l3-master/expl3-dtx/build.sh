#!/bin/bash

xetex nwafuthesis.dtx &&\
xelatex nwafuthesis.dtx &&\
makeindex -s gind.ist -o nwafuthesis.ind nwafuthesis.idx &&\
makeindex -s gglo.ist -o nwafuthesis.gls nwafuthesis.glo &&\
xelatex nwafuthesis.dtx &&\
xelatex nwafuthesis.dtx &&\
xelatex nwafuthesis.dtx
